<?php
/*

Use this file to list the mysql hosts with usernames and passwords.
Do not list that account which you already specified in phpMyBackupPro under 'configuration'!

Simply copy the next four lines as often as needed after this comment (after * / )
Replace 'localhost', 'your username' and 'your password' with your data.
Set 'use only this db' to a databases name if you only want to work with one database.
If you want to work with all accessable databases on the server set it to "" (empty).

$CONF['sql_host_s'][]="localhost";
$CONF['sql_user_s'][]="your username";
$CONF['sql_passwd_s'][]="your password";
$CONF['sql_db_s'][]="use only this db";

*/

?>
